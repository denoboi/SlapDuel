using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Sirenix.OdinInspector;
using HCB.Core;
using Newtonsoft.Json;
using System.IO;

namespace HCB.IncrimantalIdleSystem
{
    public class IdleStatBase : MonoBehaviour, IStat
    {
        [SerializeField]
        //[ValueDropdown("idKeys")]
        private string statId;
        public string StatId => statId;

        [SerializeField]
        private TextAsset idleData;

        public IdleStat IdleStat { get; set; }

        #region Editor
        private List<string> idKeys
        {
            get
            {
                List<string> ids = new List<string>();
                IdleData idleData = SaveLoadManager.LoadPDP(SavedFileNameHolder.IdleData, new IdleData(), PathPrefixes.StreamingAssets);
                foreach (var item in idleData.IdleDataCollection.Keys)
                {
                    ids.Add(item);
                }
                return ids;
            }
        }
        #endregion

        public virtual void Initialize()
        {
            IdleData data = JsonConvert.DeserializeObject<IdleData>(idleData.text);
            IdleStat = data.GetData(StatId);

            IdleStat.Level = PlayerPrefs.GetInt(StatId, 0);
        }


    }
}
