using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Sirenix.OdinInspector;
using HCB.Core;

namespace HCB.IncrimantalIdleSystem
{
    [System.Serializable]
    public class IdleData
    {
        [ShowInInspector]
        public Dictionary<string, IdleStat> IdleDataCollection = new Dictionary<string, IdleStat>();

        
        public void SaveData(string id, IdleStat stat)
        {
            IdleDataCollection[id] = stat;
            SaveLoadManager.SavePDP(this, SavedFileNameHolder.IdleData);
        }

        public IdleStat GetData(string id)
        {
            return IdleDataCollection[id];
        }
    }
}
