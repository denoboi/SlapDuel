using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Sirenix.OdinInspector;

namespace HCB.IncrimantalIdleSystem
{
    public class IdleStatData : ScriptableObject
    {

    }
}
