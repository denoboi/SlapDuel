using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

namespace HCB.IncrimantalIdleSystem.Examples
{
    public class IdleUIObject : IdleStatObjectBase
    {
        TextMeshProUGUI text;
        TextMeshProUGUI Text { get { return (text == null) ? text = GetComponent<TextMeshProUGUI>() : text; } }

        public override void Initialize()
        {
            base.Initialize();
            Text.SetText(StatId + ": " + IdleStat.CurrentValue.ToString("N0"));
        }

        public override void UpdateStat(string id)
        {
            base.UpdateStat(id);
            Text.SetText(StatId + ": " + IdleStat.CurrentValue.ToString("N0"));
        }
    }
}
