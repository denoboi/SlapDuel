using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using HCB.Core;
using Sirenix.OdinInspector;
using Sirenix.OdinInspector.Editor;

namespace HCB.IncrimantalIdleSystem.Editor
{
    public class IdleDataEditor : OdinEditorWindow
    {
        public IdleData IdleData;

        [MenuItem("HyperCasualBase/Idle Data Editor")]
        private static void OpenWindow()
        {
            GetWindow<IdleDataEditor>().Show();

        }
        [Button]
        protected override void Initialize()
        {
            base.Initialize();
            IdleData = SaveLoadManager.LoadPDP(SavedFileNameHolder.IdleData, new IdleData(), PathPrefixes.GameFolder);
        }


        [Button]
        public void SaveData()
        {
            foreach (var item in IdleData.IdleDataCollection)
            {
                PlayerPrefs.SetInt(item.Key, item.Value.Level);
            }

            SaveLoadManager.SavePDP(IdleData, SavedFileNameHolder.IdleData, PathPrefixes.GameFolder);
            AssetDatabase.Refresh();
        }

        [Button]
        public void DeleteData()
        {
            foreach (var item in IdleData.IdleDataCollection.Keys)
            {
                PlayerPrefs.DeleteKey(item);
            }

            //SaveLoadManager.DeleteFile(SavedFileNameHolder.IdleData, PathPrefixes.StreamingAssets);
            SaveLoadManager.DeleteFile(SavedFileNameHolder.IdleData, PathPrefixes.GameFolder);
            IdleData = new IdleData();
            
        }

    }
}
